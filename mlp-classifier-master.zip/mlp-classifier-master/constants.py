"""Definitions of Constants used in neuralnet""" 

#	Activation functions
SIGMOID = 'sigmoid'
SOFTMAX = 'softmax'

#	Regularization method
L2 = 'L2'
L1 = 'L1'
